let postbtn=document.getElementById('post');

postbtn.addEventListener('click', function(){
    let review=document.getElementById('HotelReview').value;
    let restname=document.getElementById('HotelName').value;
  
  var review1=document.getElementById('Hotreview');
  review1.innerHTML= review;

  var blank=document.getElementById('HotelReview');
  blank.value=null;
  var restname1=document.getElementById('Hotname');
  restname1.innerHTML= restname;
  var blank1=document.getElementById('HotelName');
  blank1.value=null;
})


let editbtn=document.getElementById('EditB');


editbtn.addEventListener('click', function(){
    document.getElementById('Restaurantreview').value=document.getElementById('Hotreview').innerHTML;
    document.getElementById('RestaurantName').value=document.getElementById('Hotname').innerHTML;

    var blank=document.getElementById('Hotreview').value;
    blank.value=null;
    console.log('chdawdwd');

})