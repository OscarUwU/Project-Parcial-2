const http = require("http");
//const { stripVTControlCharacters } = require("util");
const fs = require("fs"); //file system

const server = http.createServer(function (req, res) {
    const url = req.url;
    if (url === '/index.js') {
      res.writeHead(200, { 'Content-Type': 'text/js' }); 
      fs.createReadStream(__dirname + "/index.js", "utf8").pipe(res); 

    } else{
      res.writeHead(200, { 'Content-Type': 'text/html' }); 
      //fs.createReadStream(__dirname + "/reviews.html", "utf8").pipe(res);
      fs.createReadStream(__dirname + "/index.html", "utf8").pipe(res);
    }
});

server.listen(3000,(err)=>{
    console.log("Lisening on port 3000");
});